<?php  // Inicio del bloque de código PHP

// La función echo imprime el string proporcionado en la página web

// En este caso, imprime un encabezado de nivel 1 con el texto "Hola desde la WebApp 01"
echo "<h1>Sucess!: PHP</h1>";

// Fin del bloque de código PHP
?>